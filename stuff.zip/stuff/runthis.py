import random

with open("jobs.txt", mode="r") as file:
	contentstr = file.read()

content = contentstr.splitlines()

n = 3 # How many different jobs to prompt the user with
mylist = [random.randint(0,len(content)-1)] * n

print("I'm gonna print some job titles with numbers next to them. Type the numbers of the two that are most similar and separate them with commas. When you are done type \"done\".")
print("eg:\n1 doctor\n2 nurse\n3 firefighter\nInput: 1,2")

results = ""

while(True):
	mylist = [random.randint(0, len(content)-1)] * n;
	# Remove duplicate values
	for i in range(n-1):
		while(mylist[i+1] == mylist[i]):
			mylist[i] = random.randint(0,len(content)-1)

	for i in range(n):
		print(i+1, content[mylist[i]])

	userinput = input("Input: ")
	if(userinput == "done"):
		break
	try:
		x = list(map(int, userinput.split(",")))
	except:
		print("invalid input")
		continue

	if(len(x) != 2):
		print("invalid input")
		continue
	stupid = False
	for i in x:
		if(i > n):
			print("invalid input")
			stupid = True
	if(stupid):
		continue
	results += str(mylist[x[0]-1])
	results += ","
	results += str(mylist[x[1]-1])
	results += "\n"

with open("DATA45586739592764029.txt", mode="w") as file:
	file.write(results)
